#include "bitset.h"

// create a new, empty bit vector set with a universe of 'size' items
struct bitset * bitset_new(int size) {
  struct bitset * bitset = malloc(sizeof(struct bitset));
  bitset -> size_in_words = (size / 64);
  bitset -> universe_size = size;
  bitset -> bits = malloc(sizeof(uint64_t) * (bitset -> size_in_words));
  return bitset;
}

// get the size of the universe of items that could be stored in the set
int bitset_size(struct bitset * this) {
  return this -> universe_size;
}

// get the number of items that are stored in the set
int bitset_cardinality(struct bitset * this){
  int number_of_items = 0;
      for (int i = 0; (i < this -> size_in_words); i++){
          uint64_t word = this -> bits[i];
          while (word){
              number_of_items += word & 1;
              word >>= 1;
          }
      }
      return number_of_items;
}

// check to see if an item is in the set
int bitset_lookup(struct bitset * this, int item){
  uint64_t index_mask = 1;
  int word = (item / 64);
  index_mask = (index_mask << (item % 64));
  index_mask = (this -> bits[word]) & index_mask;
  if ((index_mask >> item) != 0){
    return 1;
  }
  return 0;
}

// add an item, with number 'item' to the set
// has no effect if the item is already in the set
void bitset_add(struct bitset * this, int item) {
  uint64_t index_mask = 1;
  int word = (item / 64);
  this->bits[word] = (this->bits[word] | (index_mask << (item % 64)));
}

// remove an item with number 'item' from the set
void bitset_remove(struct bitset * this, int item) {
  uint64_t index_mask = 1;
  int word = (item / 64);
  index_mask = ~(index_mask << (item % 64));
  this->bits[word] = (this->bits[word] & index_mask);
}

// place the union of src1 and src2 into dest;
// all of src1, src2, and dest must have the same size universe
void bitset_union(struct bitset * dest, struct bitset * src1,
    struct bitset * src2) {
      for (int i = 0; i < (dest -> size_in_words); i++)
      {
      dest->bits[i] = (src1->bits[i] | src2->bits[i]);
      }
}

// place the intersection of src1 and src2 into dest
// all of src1, src2, and dest must have the same size universe
void bitset_intersect(struct bitset * dest, struct bitset * src1,
    struct bitset * src2) {
      for (int i = 0; i < (dest -> size_in_words); i++)
       {
           dest->bits[i] = (src1->bits[i] & src2->bits[i]);
       }
}
